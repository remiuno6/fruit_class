# Base Class: Fruit
class Fruit:
    def __init__(self, name, color, taste, price_per_kg):
        self.name = name
        self.color = color
        self.taste = taste
        self.price_per_kg = price_per_kg

    def display_info(self):
        return f"Fruit: {self.name}\nColor: {self.color}\nTaste: {self.taste}\nPrice per kg: ${self.price_per_kg}"

    def apply_discount(self, percentage):
        """Apply a discount to the fruit's price"""
        self.price_per_kg -= self.price_per_kg * (percentage / 100)

# Inherited Class: Citrus (Subclass of Fruit)
class Citrus(Fruit):
    def __init__(self, name, color, taste, price_per_kg, vitamin_c_content):
        super().__init__(name, color, taste, price_per_kg)
        self.vitamin_c_content = vitamin_c_content  # in mg per 100g

    def display_info(self):
        """Override the display_info method to include Citrus-specific info"""
        basic_info = super().display_info()
        return f"{basic_info}\nVitamin C Content: {self.vitamin_c_content} mg per 100g"

    def squeeze(self):
        return f"Squeezing {self.name} to make juice!"

# Inherited Class: Berry (Subclass of Fruit)
class Berry(Fruit):
    def __init__(self, name, color, taste, price_per_kg, is_wild):
        super().__init__(name, color, taste, price_per_kg)
        self.is_wild = is_wild  # Indicates whether the berry is wild or cultivated

    def display_info(self):
        """Override the display_info method to include Berry-specific info"""
        basic_info = super().display_info()
        wild_status = "Wild" if self.is_wild else "Cultivated"
        return f"{basic_info}\nType: {wild_status}"

    def make_jam(self):
        return f"Making jam with {self.name}!"

# Demonstrating polymorphism and object creation

# Create instances of each class
fruit1 = Fruit("Apple", "Red", "Sweet", 3.50)
citrus1 = Citrus("Orange", "Orange", "Citrus", 2.00, 53)
berry1 = Berry("Blueberry", "Blue", "Sweet-Tart", 6.00, False)

# Display information
print(fruit1.display_info())
print("---------------")
print(citrus1.display_info())
print(citrus1.squeeze())
print("---------------")
print(berry1.display_info())
print(berry1.make_jam())

# Applying discount to fruit
fruit1.apply_discount(15)  # 15% discount
print("---------------")
print("After Discount:")
print(fruit1.display_info())
